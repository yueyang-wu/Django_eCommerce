from django.db import models

class CartItem(models.Model):
    pass
