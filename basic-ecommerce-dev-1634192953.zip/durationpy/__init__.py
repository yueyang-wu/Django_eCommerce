# -*- coding: UTF-8 -*-
from .duration import to_str, from_str

